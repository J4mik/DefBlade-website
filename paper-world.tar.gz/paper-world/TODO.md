# TODO
Today/Tommorow:
 - Signs/boxes small_decor

Wednesday/Thursday
 - Soundtrack
 - Fix DLLs
 - Get some playtesters.

Week 2:
 - Lasers/Guns
 - Shop
 - Soundtrack
Week 3:
 - Ui
Week 4:
 - Extra Enemies
 - Backgrounds
 - Clouds

Extra:
 - Shaders
 - Conveyer belts
 - Wind tunnel (to carry you up)
 - Cloth (hard)

Release:
 - Remove FPS counter
 - Fix DLLS
 - You Win
 - Check & playthrough levels. Check they are possible and check for mishaps.